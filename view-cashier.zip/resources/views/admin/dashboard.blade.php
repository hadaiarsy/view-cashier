@extends('admin.temp.template')

@section('site-title', 'Dashboard')

@section('main-contents')
    <div class="row">
        <div class="col-sm-2">
            <h4>Dashboard</h4>
            <hr class="divider">
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-12">
            <h3>WAROENG YAMUGHNI</h3>
        </div>
    </div>
@endsection
