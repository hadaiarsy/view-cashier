@extends('admin.temp.template')

@section('site-title', 'Stok')

@section('main-contents')

@endsection
