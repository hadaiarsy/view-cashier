<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="url-global" content="<?php echo e(config('app.url')); ?>">

    <style>
        * {
            font-family: arial, sans-serif;
            font-size: 1rem;
        }

        body {
            font-size: 0.1rem;
        }

        /* div.container {
            background-color: rgb(39, 38, 38);
        } */

        tr.list-item th {
            text-align: left
        }

        tr.head-list td {
            text-align: center
        }

        table#dataTransaksi {
            width: 100%;
            border-collapse: collapse;
        }

        table#dataTransaksi,
        table#dataTransaksi th,
        table#dataTransaksi td {
            border: 1px solid black;
            font-size: 0.9rem;
        }

        table#dataMember {
            width: 100%;
            margin-bottom: 20px;
        }

        table#dataMember td {
            width: 50%;
        }

        tr.border-bottom td {
            border-bottom: 1px solid black;
        }

        tr.border-full td {
            border: 1px solid black;
        }

        td.border-right {
            vertical-align: top;
            border-right: 1px solid black;
        }

        div#laporanLand {
            width: 80%;
            margin: auto;
            margin-top: 40px;
            border: 1px solid black;
            padding: 12px;
        }

        div.row-button {
            width: 80%;
            margin: auto;
            margin-top: 40px;
        }

    </style>

    <title>Laporan Transaksi</title>
</head>

<body>
    <div class="container">
        <div id="">
            <table id="dataMember">
                <thead>
                    <tr class="head-list">
                        <th colspan="2">
                            <h4>BUKU PEMBELIAN</h4>
                            <h4 style="margin-top: -16px">KOPERASI YAMUGHNI</h4>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tanggal : <?php echo e(date('d-m-Y')); ?></td>
                        <td>No. Cetak : <?php echo e($number); ?></td>
                    </tr>
                    <tr>
                        <td>ID User : <?php echo e($userid); ?></td>
                    </tr>
                </tbody>
            </table>
            <table id="dataTransaksi">
                <thead>
                    <tr style="height: 30px;">
                        <th scope="col" rowspan="2" style="width: 3%">NO.</th>
                        <th scope="col" colspan="2" style="width: 14%">FAKTUR</th>
                        <th scope="col" rowspan="2">NAMA PEMBELI</th>
                        <th scope="col" rowspan="2">NAMA BARANG</th>
                        <th scope="col" rowspan="2" style="width: 8%">BANYAKNYA</th>
                        <th scope="col" rowspan="2">HARGA SATUAN (Rp.)</th>
                        <th scope="col" rowspan="2">JUMLAH HARGA (Rp.)</th>
                        <th scope="col" rowspan="2">TOTAL FAKTUR (Rp.)</th>
                        <th scope="col" rowspan="2">TANGGAL LUNAS</th>
                        <th scope="col" rowspan="2">KET.</th>
                    </tr>
                    <tr style="height: 30px;">
                        <th scope="col">TGL PB</th>
                        <th scope="col">INV/DPB</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $tp = 0; ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="head-list">
                            <th scope="col" rowspan="<?php echo e(count($transaksi->detail)); ?>"><?php echo e($loop->iteration); ?></th>
                            <td rowspan="<?php echo e(count($transaksi->detail)); ?>">
                                <?php echo e(date('d/m/y', strtotime($transaksi->tanggal))); ?></td>
                            <td rowspan="<?php echo e(count($transaksi->detail)); ?>"><?php echo e($transaksi->no_dpb); ?></td>
                            <td rowspan="<?php echo e(count($transaksi->detail)); ?>"><?php echo e($transaksi->member->nama); ?></td>
                            <td><?php echo e($transaksi->detail[0]->nama_barang); ?></td>
                            <td><?php echo e($transaksi->detail[0]->jumlah . ' ' . $transaksi->detail[0]->satuan); ?></td>
                            <td><?php echo e((int) $transaksi->detail[0]->harga / (int) $transaksi->detail[0]->jumlah); ?></td>
                            <td><?php echo e($transaksi->detail[0]->harga); ?></td>
                            <td rowspan="<?php echo e(count($transaksi->detail)); ?>"><?php echo e($transaksi->total); ?></td>
                            <td rowspan="<?php echo e(count($transaksi->detail)); ?>">
                                <?php echo e($transaksi->is_lunas == 1 ? date('d/m/y', strtotime($transaksi->tanggal)) : '-'); ?>

                            </td>
                            <td rowspan="<?php echo e(count($transaksi->detail)); ?>">
                                <?php echo e($transaksi->is_lunas == 1 ? 'LUNAS' : 'TENGGAT WAKTU: ' . date('d/m/y', strtotime('+30 days', strtotime($transaksi->tanggal)))); ?>

                            </td>
                        </tr>
                        <?php if(count($transaksi->detail) > 1): ?>
                            <?php for($i = 1; $i <= count($transaksi->detail) - 1; $i++): ?>
                                <tr class="head-list">
                                    <td><?php echo e($transaksi->detail[$i]->nama_barang); ?></td>
                                    <td><?php echo e($transaksi->detail[$i]->jumlah . ' ' . $transaksi->detail[$i]->satuan); ?>

                                    </td>
                                    <td><?php echo e((int) $transaksi->detail[$i]->harga / (int) $transaksi->detail[$i]->jumlah); ?>

                                    </td>
                                    <td><?php echo e($transaksi->detail[$i]->harga); ?></td>
                                </tr>
                            <?php endfor; ?>
                        <?php endif; ?>
                        <?php $tp += $transaksi->total; ?>
                        <?php if($loop->last): ?>
                            <tr>
                                <th colspan="8" style="text-align: right">TOTAL PEMBELIAN (Rp. )</th>
                                <td style="text-align: center"><?php echo e($tp); ?></td>
                                <td></td>
                                <td></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\view-cashier\resources\views/admin/transaksi/laporanharianpembelian.blade.php ENDPATH**/ ?>