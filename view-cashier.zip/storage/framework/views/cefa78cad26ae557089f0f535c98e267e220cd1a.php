<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="url-global" content="<?php echo e(config('app.url')); ?>">

    <style>
        * {
            font-family: arial, sans-serif;
            font-size: 1rem;
        }

        /* div.container {
            background-color: rgb(39, 38, 38);
        } */

        tr.list-item th {
            text-align: left
        }

        tr.head-list td {
            text-align: center
        }

        table#dataTransaksi {
            width: 100%;
            border-collapse: collapse;
        }

        table#dataTransaksi,
        table#dataTransaksi th,
        table#dataTransaksi td {
            border: 1px solid black;
        }

        table#dataMember {
            width: 100%;
            margin-bottom: 20px;
        }

        table#dataMember td {
            width: 50%;
        }

        tr.border-bottom td {
            border-bottom: 1px solid black;
        }

        tr.border-full td {
            border: 1px solid black;
        }

        td.border-right {
            vertical-align: top;
            border-right: 1px solid black;
        }

        div#laporanLand {
            width: 80%;
            margin: auto;
            margin-top: 40px;
            border: 1px solid black;
            padding: 12px;
        }

        div.row-button {
            width: 80%;
            margin: auto;
            margin-top: 40px;
        }

    </style>

    <title>Laporan Transaksi</title>
</head>

<body>
    <div class="container">
        <div class="row row-button">
            <a href="<?php echo e(route('download-pdf', $member->kode_member)); ?>" target="_blank"><button type="button">Download
                    PDF</button></a>
        </div>
        <div id="laporanLand">
            <table id="dataMember">
                <thead>
                    <tr class="head-list">
                        <th colspan="2">
                            <h4>Riwayat Transaksi</h4>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Nama: <?php echo e($member->nama); ?></td>
                        <td>Kode unit: <?php echo e($member->kode_member); ?></td>
                    </tr>
                    <tr>
                        <td>Unit: <?php echo e($member->unit); ?></td>
                        <td>Tanggal: <?php echo e(date('d-m-Y')); ?></td>
                    </tr>
                </tbody>
            </table>
            <table id="dataTransaksi">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col" style="width: 24%">Invoice Transaksi</th>
                        <th scope="col">Kode Produk</th>
                        <th scope="col">Nama Produk</th>
                        <th scope="col">Jumlah</th>
                        <th scope="col">Ket</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $t->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="head-list">
                                <th scope="col"><?php echo e($num++); ?></th>
                                <td><?php echo e($detail->transaksi_id); ?></td>
                                <td><?php echo e($detail->kode_barang); ?></td>
                                <td><?php echo e($detail->nama_barang); ?></td>
                                <td><?php echo e($detail->jumlah . ' ' . $detail->nama_satuan); ?></td>
                                <td></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\view-cashier\resources\views/admin/transaksi/laporan.blade.php ENDPATH**/ ?>