<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Jquery cdn -->
    <script src="<?php echo e(asset('assets/js/jquery-3.5.1.js')); ?>"></script>

    <!-- Jquery QR Code -->
    <script src="<?php echo e(asset('assets/js/jquery.qrcode.min.js')); ?>"></script>

    <style>
        * {
            font-size: 0.88rem
        }

        table.border-table {
            border-collapse: collapse
        }

        table.border-table td,
        table.border-table th {
            border: 1px solid black
        }

        .text-center {
            text-align: center
        }

    </style>

    <title>Print Faktur</title>
</head>

<body style="width: 100%">

    <table id="headFaktur" style="width: 100%; padding-top: 40px">
        <tr>
            <td class="text-center"><strong>PIUTANG</strong></td>
        </tr>
    </table>

    <table class="" id="profil" style="width: 100%; margin-top: 10px">
        <tr>
            <td style="text-align: right; width: 43%">
                <img src='<?php echo e(asset('assets/img/icon/logo.png')); ?>' alt='yamughni' style="width: 60px">
            </td>
            <td style="text-align: left; width: 50%">
                <strong>WAROENG YAMUGHNI</strong>
            </td>
        </tr>
    </table>

    <div style="display: flex; margin-left: 20px">
        <table id="dataMember" style="margin: 20px 0 0 20px">
            <tr>
                <td>ID User</td>
                <td>:</td>
                <td><?php echo e($data->member->nama . ' | ' . $data->member->kode_member); ?></td>
            </tr>
            <tr>
                <td>Tanggal</td>
                <td>:</td>
                <td><?php echo e(date('d M Y', strtotime($data->tanggal))); ?></td>
            </tr>
        </table>

        <table id="dataFaktur" style="margin-top: 20px; position: absolute; right: 80px; display: inline-block">
            <tr>
                <td>Faktur no</td>
                <td>:</td>
                <td><?php echo e($data->no_resi); ?></td>
            </tr>
            <tr>
                <td>ID Admin</td>
                <td>:</td>
                <td><?php echo e($data->kasir->name . ' | ' . $data->kasir->id); ?></td>
            </tr>
        </table>
    </div>

    <table id="dataBarang" style="margin: 20px 20px 0; width: 95%">
        <?php if(count($data->piutang) != 0): ?>
            <tr>
                <td><strong>Cicilan ke-<?php echo e(count($data->piutang)); ?></strong></td>
            </tr>
        <?php endif; ?>
    </table>
    <table class="border-table" id="dataBarang" style="margin: auto; width: 85%">
        <thead>
            <th scope="col">No.</th>
            <th scope="col">Kode Barang</th>
            <th scope="col">Nama Barang</th>
            <th scope="col">Jumlah Item</th>
            <th scope="col">Harga</th>
            <th scope="col">Total</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="col"><?php echo e($loop->iteration); ?></th>
                    <td class="text-center"><?php echo e($barang->kode_barang); ?></td>
                    <td class="text-center"><?php echo e($barang->nama_barang); ?></td>
                    <td class="text-center"><?php echo e($barang->jumlah . ' ' . $barang->satuan); ?></td>
                    <td class="text-center"><?php echo e($barang->harga / $barang->jumlah); ?></td>
                    <td class="text-center"><?php echo e($barang->harga); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="col" colspan="5" style="text-align: right">Total Piutang</th>
                <td class="text-center"><?php echo e($data->total); ?></td>
            </tr>
            <tr>
                <?php $tp = 0; ?>
                <th scope="col" colspan="5" style="text-align: right">Pembayaran Sebelumnya</th>
                <td class="text-center">
                    <?php $__currentLoopData = $data->piutang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piutang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$loop->last): ?>
                            <?php $tp += $piutang->uang; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($tp); ?>

                </td>
            </tr>
        </tbody>
    </table>

    <div style="display: flex">
        <table style="width: 80%; margin: 30px 60px;">
            <tr>
                <td style="width: 18%"><span style="border-bottom: 1px solid black">Pembeli</span></td>
                <td><span style="border-bottom: 1px solid black">Admin</span></td>
            </tr>
            <tr>
                <td colspan="2" style="padding-top: 80px">
                    <p>Jl. Kaum No.2 (Samping Terminal Cicaheum) | (022) 20503797 | koperasiyamughni11@gmail.com |
                        yamughnibandung.org</p>
                </td>
            </tr>
        </table>

        <table style="display: inline-block; margin: 20px 0; position: absolute; right: 80px;">
            <?php $sp = 0; ?>
            <tr>
                <td>Saldo Awal</td>
                <td>:</td>
                <td>
                    <?php $__currentLoopData = $data->piutang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piutang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$loop->last): ?>
                            <?php $sp += $piutang->uang; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $sp = $data->total - $sp; ?>
                    <?php echo e($sp < 0 ? 0 : $sp); ?>

                </td>
            </tr>
            <tr>
                <td>Bayar</td>
                <td>:</td>
                <td>
                    <?php if(count($data->piutang) != 0): ?>
                        <?php echo e($bayar = $data->piutang[count($data->piutang) - 1]->uang); ?>

                    <?php else: ?>
                        <?php $bayar = 0; ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Kembali</td>
                <td>:</td>
                <td><?php echo e($kembali = $bayar - $sp < 0 ? '-' : $kembali); ?></td>
            </tr>
            <tr>
                <td>Sisa Piutang</td>
                <td>:</td>
                <td><?php echo e($sisa = $sp - $bayar < 0 ? 0 : $sp - $bayar); ?></td>
            </tr>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            function currencyIdr(angka, prefix) {
                let number_string = angka.replace(/[^,\d]/g, "").toString(),
                    split = number_string.split(","),
                    sisa = split[0].length % 3,
                    rupiah = split[0].substr(0, sisa),
                    ribuan = split[0].substr(sisa).match(/\d{3}/gi);
                if (ribuan) {
                    separator = sisa ? "." : "";
                    rupiah += separator + ribuan.join(".");
                }
                rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
                return prefix == undefined ? rupiah : rupiah ? "Rp " + rupiah : "";
            }

            $('.harga-item-struk').each(function(e) {
                $(this).html(currencyIdr(String($(this).html()), 'Rp '))
            })

            $('#totalStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#grandTotalStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#uangStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#kembaliStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            let d = new Date();
            let month = d.getMonth() + 1;
            let day = d.getDate();
            let outputDate = (day < 10 ? '0' : '') + day + '-' +
                (month < 10 ? '0' : '') + month + '-' +
                d.getFullYear();

            $('#qrcodeStruk').qrcode({
                width: 60,
                height: 60,
                text: 'https://www.yamughnibandung.org/'
            });

            window.print();

        })

    </script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\view-cashier\resources\views/admin/transaksi/faktur.blade.php ENDPATH**/ ?>