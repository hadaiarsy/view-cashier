<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Jquery cdn -->
    <script src="<?php echo e(asset('assets/js/jquery-3.5.1.js')); ?>"></script>

    <!-- Jquery QR Code -->
    <script src="<?php echo e(asset('assets/js/jquery.qrcode.min.js')); ?>"></script>

    <title>Test Struk</title>
</head>

<body style="width: 100%">

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table id='printStruk'
            style='align-items: center; justify-content: center; font-size: 11px; font-weight: bold; border-top: 1px dashed black; border-bottom: 1px dashed black; border-spacing: 8px; width: 186px'>
            <tr>
                <td colspan='3' style='text-align: center'>
                    <img src='<?php echo e(asset('assets/img/icon/logo.png')); ?>' alt='yamughni img' style='width: 60px'>
                </td>
            </tr>
            <tr>
                <td colspan='3' style='text-align: center'>WAROENG YAMUGHNI</td>
            </tr>
            <tr>
                <td colspan='3' style='text-align: center'>Tgl:
                    <?php echo e(date('d-m-Y H:i:s', strtotime($transaksi->tanggal))); ?></br>Unit:
                    <?php echo e($transaksi->member->kode_member == 'U-00-01' ? '-' : $transaksi->member->kode_member); ?>

                </td>
            </tr>
            <tr style='margin-bottom: 20px'>
                <td style='border-bottom: 1px solid black;'>ID Kasir:</br><?php echo e($transaksi->kasir->id); ?></td>
                <td colspan='2' style='border-bottom: 1px solid black; text-align: right'>No.
                    Resi:</br><?php echo e($transaksi->no_resi); ?>

                </td>
            </tr>
            <?php if($transaksi->is_lunas == '0'): ?>
                <tr>
                    <td colspan='3' style='border-bottom: 1px dashed black; text-align: center;'>
                        PIUTANG
                    </td>
                </tr>
            <?php endif; ?>
            <?php $__currentLoopData = $transaksi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detail->nama_barang); ?></td>
                    <td style='text-align: center'><?php echo e($detail->jumlah . ' ' . $detail->satuan); ?></td>
                    <td class='harga-item-struk' style='text-align: right'>Rp <?php echo e($detail->harga); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($transaksi->diskon > 0): ?>
                <tr>
                    <td style='border-top: 1px solid black;'>Total</td>
                    <td colspan='2' id='totalStruk' style='border-top: 1px solid black; text-align: right'>
                        <?php echo e($total); ?>

                    </td>
                </tr>
                <tr>
                    <td>Diskon</td>
                    <td colspan='2' style='text-align: right'><?php echo e($transaksi->diskon); ?> %</td>
                </tr>
            <?php endif; ?>
            <tr>
                <?php if($transaksi->is_lunas == '1'): ?>
                    <td style='border-top: 1px solid black;'>Grand Total</td>
                <?php else: ?>
                    <td style='border-top: 1px solid black;'>Total Piutang</td>
                <?php endif; ?>
                <td colspan='2' id='grandTotalStruk' style='border-top: 1px solid black; text-align: right'>
                    <?php echo e($transaksi->total); ?>

                </td>
            </tr>
            <tr>
                <td>Uang</td>
                <td colspan='2' id='uangStruk' style='text-align: right'><?php echo e($uang); ?></td>
            </tr>
            <?php if($transaksi->is_lunas == '1'): ?>
                <tr>
                    <td>Kembali</td>
                    <td colspan='2' id='kembaliStruk' style='text-align: right'>
                        <?php echo e($kembali); ?>

                    </td>
                </tr>
            <?php else: ?>
                <tr>
                    <td>Sisa Piutang</td>
                    <td colspan='2' id='kembaliStruk' style='text-align: right'>
                        <?php echo e((int) $transaksi->total - (int) $uang); ?></td>
                </tr>
                <tr>
                    <td colspan='3' style='border-top: 1px solid black; text-align: center;'>Struk
                        PIUTANG!</br>Jangan sampai hilang!
                    </td>
                </tr>
            <?php endif; ?>
            <tr>
                <td colspan='3' style='border-top: 1px solid black; text-align: center'>Terima Kasih</td>
            </tr>
            <tr>
                <td colspan='3' style='border-top: 1px solid black; text-align: center;'>
                    <div id='qrcodeStruk'></div>
                </td>
            </tr>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        $(document).ready(function() {
            function currencyIdr(angka, prefix) {
                let number_string = angka.replace(/[^,\d]/g, "").toString(),
                    split = number_string.split(","),
                    sisa = split[0].length % 3,
                    rupiah = split[0].substr(0, sisa),
                    ribuan = split[0].substr(sisa).match(/\d{3}/gi);
                if (ribuan) {
                    separator = sisa ? "." : "";
                    rupiah += separator + ribuan.join(".");
                }
                rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
                return prefix == undefined ? rupiah : rupiah ? "Rp " + rupiah : "";
            }

            $('.harga-item-struk').each(function(e) {
                $(this).html(currencyIdr(String($(this).html()), 'Rp '))
            })

            $('#totalStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#grandTotalStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#uangStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#kembaliStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            let d = new Date();
            let month = d.getMonth() + 1;
            let day = d.getDate();
            let outputDate = (day < 10 ? '0' : '') + day + '-' +
                (month < 10 ? '0' : '') + month + '-' +
                d.getFullYear();

            $('#qrcodeStruk').qrcode({
                width: 60,
                height: 60,
                text: 'https://www.yamughnibandung.org/'
            });

            window.print();

        })

    </script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\view-cashier\resources\views/admin/transaksi/test.blade.php ENDPATH**/ ?>