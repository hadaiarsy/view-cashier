<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Jquery cdn -->
    <script src="<?php echo e(asset('assets/js/jquery-3.5.1.js')); ?>"></script>

    <!-- Jquery QR Code -->
    <script src="<?php echo e(asset('assets/js/jquery.qrcode.min.js')); ?>"></script>

    <title>Struk Piutang</title>
</head>

<body style="width: 100%">

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table id='printStruk'
            style='align-items: center; justify-content: center; font-size: 11px; font-weight: bold; border-top: 1px dashed black; border-bottom: 1px dashed black; border-spacing: 8px; width: 186px'>
            <tr>
                <td colspan='3' style='text-align: center'>
                    <img src='<?php echo e(asset('assets/img/icon/logo.png')); ?>' alt='yamughni img' style='width: 60px'>
                </td>
            </tr>
            <tr>
                <td colspan='3' style='text-align: center'>WAROENG YAMUGHNI</td>
            </tr>
            <tr>
                <td colspan='3' style='text-align: center'>Tgl:
                    <?php echo e(date('d-m-Y', strtotime($transaksi->tanggal))); ?></br>Unit:
                    <?php echo e($transaksi->member->unit == null ? '-' : $transaksi->member->unit); ?>

                    | <?php echo e($transaksi->member->kode_member); ?>

                </td>
            </tr>
            <tr style='margin-bottom: 20px'>
                <td style='border-bottom: 1px solid black;'>ID Kasir:</br><?php echo e($transaksi->kasir->id); ?></td>
                <td colspan='2' style='border-bottom: 1px solid black; text-align: right'>No.
                    Resi:</br><?php echo e($transaksi->no_resi); ?>

                </td>
            </tr>
            <?php if($transaksi->is_lunas == '0'): ?>
                <tr>
                    <td colspan='3' style='border-bottom: 1px dashed black; text-align: center;'>
                        Pembayaran PIUTANG
                    </td>
                </tr>
            <?php endif; ?>
            <tr>
                <td>Saldo Awal</td>
                <td colspan='2' id='saldoAwal' style='text-align: right'><?php echo e($saldoAwal); ?></td>
            </tr>
            <?php $__currentLoopData = $transaksi->piutang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piutang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($piutang->id == $idPiutang): ?>
                    <tr>
                        <td>Uang</td>
                        <td colspan='2' id='uangStruk' style='text-align: right'><?php echo e($piutang->uang); ?></td>
                    </tr>
                    <?php if($transaksi->is_lunas == '1'): ?>
                        <tr>
                            <td>kembali</td>
                            <td colspan='2' id='kembali' style='text-align: right'>
                                <?php echo e($saldoAwal - $piutang->uang); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Sisa Piutang</td>
                <td colspan='2' id='sisaPiutang' style='text-align: right'>
                    <?php echo e($sisa); ?>

                </td>
            </tr>
            <?php if($transaksi->is_lunas == '1'): ?>
                <tr>
                    <td colspan='3' style='border-top: 1px dashed black; text-align: center'>LUNAS</td>
                </tr>
            <?php endif; ?>
            <tr>
                <td colspan='3' style='border-top: 1px solid black; text-align: center'>Terima Kasih</td>
            </tr>
            <tr>
                <td colspan='3' style='border-top: 1px solid black; text-align: center;'>
                    <div id='qrcodeStruk'></div>
                </td>
            </tr>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        $(document).ready(function() {
            function currencyIdr(angka, prefix) {
                let number_string = angka.replace(/[^,\d]/g, "").toString(),
                    split = number_string.split(","),
                    sisa = split[0].length % 3,
                    rupiah = split[0].substr(0, sisa),
                    ribuan = split[0].substr(sisa).match(/\d{3}/gi);
                if (ribuan) {
                    separator = sisa ? "." : "";
                    rupiah += separator + ribuan.join(".");
                }
                rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
                return prefix == undefined ? rupiah : rupiah ? "Rp " + rupiah : "";
            }

            $('.harga-item-struk').each(function(e) {
                $(this).html(currencyIdr(String($(this).html()), 'Rp '))
            })

            $('#saldoAwal').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#uangStruk').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#kembali').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            $('#sisaPiutang').html(function() {
                return currencyIdr(String($(this).html()), 'Rp ')
            })

            let d = new Date();
            let month = d.getMonth() + 1;
            let day = d.getDate();
            let outputDate = (day < 10 ? '0' : '') + day + '-' +
                (month < 10 ? '0' : '') + month + '-' +
                d.getFullYear();

            $('#qrcodeStruk').qrcode({
                width: 60,
                height: 60,
                text: 'https://www.yamughnibandung.org/'
            });

            window.print();

        })

    </script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\view-cashier\resources\views/admin/transaksi/strukpiutang.blade.php ENDPATH**/ ?>